import UIKit

var ismim = "Samet"

var soyismim = "Temel"

print(ismim)

ismim = "samet"

print(ismim)

var userName = "test"
var internettenGelenEnYeniVeri = 50 // camelCase
var internetten_gelen_en_yeni_veri = 40 // snake_case
